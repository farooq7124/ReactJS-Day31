import React from 'react'
import { connect } from 'react-redux'
import { removeTodo } from '../actions'

let RemoveTodo = ({ dispatch }) => {

  return (
    <div>
      <form onSubmit={e => {
        e.preventDefault()
         
        dispatch(removeTodo())
      }}>
        
        <button type="submit">
          Remove Todo
        </button>
      </form>
    </div>
  )
}
RemoveTodo = connect()(RemoveTodo)

export default RemoveTodo

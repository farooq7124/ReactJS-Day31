import React from 'react'
import Footer from './Footer'
import AddTodo from '../containers/AddTodo'
import RemoveTodo from '../containers/RemoveTodo'
import VisibleTodoList from '../containers/VisibleTodoList'

const App = () => (
  <div>
    <AddTodo />
	<RemoveTodo />
    <VisibleTodoList />
    <Footer />
  </div>
)

export default App
